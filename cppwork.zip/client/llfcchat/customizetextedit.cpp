#include "customizetextedit.h"

CustomizeTextEdit::CustomizeTextEdit(QWidget *parent):QTextEdit (parent)
{

}
